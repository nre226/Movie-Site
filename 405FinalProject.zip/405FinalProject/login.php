
<?php
//login.php
	include "header.php";
	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
	if (!$conn) {
		die("Didnt conek sonny");
	}
	$curr_db = mysql_select_db('405GMDB', $conn);

	$email = ($_POST["user-email"]);
	$pass = ($_POST["user-pass"]);

	$query = "SELECT  `email` ,  `pass` FROM  `user` WHERE  `email` =  '$email'";
	$result = mysql_query($query);
	$count = mysql_num_rows($result);

	if ($count == 1 && (mysql_result($result, 0, 'pass') == $pass)) {
		$_SESSION["username"] = mysql_result($result, 0, "fname");
		if (mysql_result($result, 0, 'type') == 'admin') {
			$_SESSION['isadmin'] = true;
		}
		else {
			$_SESSION['isadmin'] = false;
		}
	    echo "<script type='text/javascript'>alert('Welcome $email!');</script>";
		echo "<script type='text/javascript'>
    		window.location = 'index.php';
		</script>";
	}

	else {
		echo "<script type='text/javascript'>alert('Please enter a valid email and password, or register as a new user');</script>";
		echo "<script type='text/javascript'>
    		window.location = 'index.php';
		</script>";
	}

	include "footer.php";

?>
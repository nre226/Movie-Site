
<ul id="admintools">

<?php 
	echo "<form method='post' action='new-movie.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-movie' value='' class='btn btn-info'>
    				Add a New Movie
  				</button>
			</form>";
	echo "<form method='post' action='registration.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-user' value='' class='btn btn-info'>
    				Add a New User
  				</button>
			</form>";
	echo "<form method='post' action='new-crew.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-crew' value='' class='btn btn-info'>
    				Add a New Crew
  				</button>
			</form>";
	echo "<form method='post' action='new-genre.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-genre' value='' class='btn btn-info'>
    				Add a New Genre
  				</button>
			</form>";
	echo "<form method='post' action='new-rating.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-rating' value='' class='btn btn-info'>
    				Add a New Rating
  				</button>
			</form>";
	echo "<form method='post' action='new-role.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-role' value='' class='btn btn-info'>
    				Add a New Role
  				</button>
			</form>";
	echo "<form method='post' action='new-tag.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-tag' value='' class='btn btn-info'>
    				Add a New Tag
  				</button>
			</form>";
	echo "<form method='post' action='new-promotion.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='open-new-tag' value='' class='btn btn-info'>
    				Promote To Admin
  				</button>
			</form>";

?>
</ul>
<?php
	//promote users
	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
	if (!$conn) {
		die("Didnt conek sonny");
	}
	$curr_db = mysql_select_db('405GMDB', $conn);

	$userid = ($_POST["user-id"]);
  	
  	$query = "UPDATE user SET type = 'admin'";
	if (mysql_query($query)) {
		echo "<script type='text/javascript'>alert('Thank you for updating!');</script>";
		echo "<script type='text/javascript'>
    		window.location = 'index.php';
		</script>";
	}
	else {
		echo "Error: " . $query . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);

?>
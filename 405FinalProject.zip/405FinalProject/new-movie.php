<?php include "header.php"; ?>

	<div class="container">
	    <form class="form-horizontal" role="form" method="post" action="./addMovie.php">
	    <h2>Make a New Movie</h2>
	    <hr/>
	        <div class="form-group">
	            <label for="movie-title" class="col-sm-3 control-label">Movie Title</label>
	            <div class="col-sm-9">
	                <input type="text" name="movie-title" placeholder="Title" class="form-control" autofocus>
	            </div>
	        </div>
	        <div class="form-group">
	            <label for="movie-description" class="col-sm-3 control-label">Decription</label>
	            <div class="col-sm-9">
	                <textarea type="text" name="movie-description" placeholder="Describe the movie" class="form-control"></textarea>
	            </div>
	        </div>
	        <div class="form-group">
	            <label for="movie-release" class="col-sm-3 control-label">Release Date (year)</label>
	            <div class="col-sm-9">
	                <input type="text" name="movie-release" class="form-control">
	            </div>
	        </div>

	        <div class="form-group">
	            <label for="movie-duration" class="col-sm-3 control-label">Movie Duration</label>
	            <div class="col-sm-9">
	                <input type="text" name="movie-duration" placeholder="Duration" class="form-control" autofocus>
	            </div>
	        </div>

	        <div class="form-group">
	            <label for="movie-language" class="col-sm-3 control-label">Movie Language</label>
	            <div class="col-sm-9">
	                <input type="text" name="movie-language" placeholder="Language" class="form-control" autofocus>
	            </div>
	        </div>

	        
	        <div class="form-group">
	            <div class="col-sm-9 col-sm-offset-2" role="submitbutton">
	                <button type="submit" class="btn btn-primary btn-block">Add Movie</button>
	            </div>
	        </div>
	    </form> <!-- /form -->

	</div> <!-- ./container -->

<?php include "footer.php"; ?>
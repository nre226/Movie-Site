 	
 	<nav class="navbar navbar-default navbar-fixed-bottom" id="footbar">
        <div class="container-fluid">
            <div class="navbar-footer">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myFootbar">
                <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
              </button>
            </div>
            <div class="collapse navbar-collapse" id=myFootbar>
                <ul class="nav navbar-nav">
                    <li><a href="https://www.facebook.com/dean.crockett.98"><span class="fa fa-facebook-square fa-lg" id="fb"></span></a></li>
                    <li><a href="mailto:deancrockett.ky@gmail.com?Subject=Test%20mail" target="_top"><span class="fa fa-envelope-o fa-lg" id="mail"></span> Contact us</a></li>
                </ul>
            </div>
        </div>
        </nav>

</body>
</html>
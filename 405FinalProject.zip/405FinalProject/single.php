<?php include 'header.php'; ?>

<style type="text/css">
   body { background: #444444 !important; } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */
</style>

<div class="container">
	<div class="row">
		<div class="col-md-3">
		</div>
	<div class="col-md-6" role="testing">
		<div class="row">
				<?php
					$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
					if (!$conn) {
						die("Didnt conek sonny");
					}
					$curr_db = mysql_select_db('405GMDB', $conn);

					$moviename = ($_POST["movie-name"]);

					$query = "SELECT * FROM movies WHERE title = '$moviename'";
					$result = mysql_query($query);
					$movienum = mysql_result($result, 0, "movie_id");
					$title = mysql_result($result, 0, "title");
					$description = mysql_result($result, 0, "description");
					$runtime = mysql_result($result, 0, 'duration');
					$releasedate= mysql_result($result, 0, 'release');
					$movielang = mysql_result($result, 0, 'language');
					$moviepic = mysql_result($result, 0, 'movie_pic');
					echo "<div class='col-sm-6'>
						<img src='$moviepic' class='img-thumbnail'>
						</div>";
					echo "<div class='col-sm-6'>";
					echo "<h1>$title</h1>";

					

				?>				
				<h3>Average Rating</h3>
				<?php
					$avg = 0;
					$ratings = "SELECT * FROM rating WHERE movie_id = '$movienum'";
					$rresult = mysql_query($ratings);
					$count = mysql_num_rows($rresult);
					while ($row = mysql_fetch_assoc($rresult)) {
						$avg += $row['rating'];
					}
					$avg = $avg / $count;
					echo " <strong id='movie-avg-rating'>$avg</strong>";

				?>
			</div>
		</div>
		<!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/YoHD9XEInc0" frameborder="0" allowfullscreen></iframe> -->
		<?php 
			echo "<h3 class='runtime'>Runtime:</h3>";
			echo "<p>$runtime minutes</p>";

			$genreq = "SELECT * FROM genre WHERE movie_id = '$movienum'";
			$resultg = mysql_query($genreq);

			echo "<h3 class='genres'> Genres: </h3>";

			while ($row = mysql_fetch_assoc($resultg)) {
   					echo "<p class='genre'>{$row["genre"]}</p><br>";
			}
			echo "<br>";

			echo "<h3 class='reldate'>Release Date</h3>";
			echo "$releasedate";
			echo "<br>";
			echo "<div class='description'>
			<p>$description</p></div>";

		
		?>
		<div class="crew">
			<h3>Crew:</h3>
			<?php
				$crewq = "SELECT * FROM crew WHERE crew_id = '$movienum'";
				$resultc = mysql_query($crewq);
				while ($row = mysql_fetch_assoc($resultc)) {
   					echo "<p class='crew'>{$row["first_name"]} {$row["middle_name"]} {$row["last_name"]} </p><br>";
				}
			?>
		</div>
		<hr/>
		<div class="responses">
			<?php
				$ratings = "SELECT * FROM rating WHERE movie_id = '$movienum'";
				$rresult = mysql_query($ratings);
				$count = mysql_num_rows($rresult);
				echo "<h3>Responses ($count)</h3>";
				while ($row = mysql_fetch_assoc($rresult)) {
					echo "<p>{$row["review"]} </p><br>";
				}
			?>
		</div>
		<hr/>
		<h4>Leave a rating!</h4>
		<form class='form-horizontal' method='post' action='addRating.php'>

			<input type="hidden" name="user-id" value='1'>
			<input type='hidden' name='movie-id' value='<?php echo "$movienum"; ?>'>

			<fieldset class="rating">
    			<input type="radio" id="star5" name="user-rating" value="5" />
    			<label for="star5"> </label>
    			<input type="radio" id="star4" name="user-rating" value="4" />
    			<label for="star4"> </label>
    			<input type="radio" id="star3" name="user-rating" value="3" />
    			<label for="star3"> </label>
    			<input type="radio" id="star2" name="user-rating" value="2" />
    			<label for="star2"> </label>
    			<input type="radio" id="star1" name="user-rating" value="1" />
    			<label for="star1"> </label>
			</fieldset>

	        <div class="form-group">
	            <div class="col-sm-9">
	                <input type="text" name="user-review" placeholder="Review" class="form-control" autofocus>
	            </div>
	        </div>

	        <div class="form-group">
	            <div class="col-sm-9 col-sm-offset-2" role="submitbutton">
	                <button type="submit" class="btn btn-primary">Submit Review</button>
	            </div>
	        </div>

		</form>
	</div>
</div>

<?php include 'footer.php'; ?>

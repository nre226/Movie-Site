<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 */
	session_start();

?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<title>Cinema Archives DataBase</title>
	<link rel="stylesheet" href="/app.css">
	<script src="/app.js"></script>
	<script>require('initialize');</script>
	<!-- Bootstrap Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Slick slideshow plugin -->
	<link rel="stylesheet" type="text/css" href="slick/slick.css"/>
	<link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>
	<!-- fontawesome favicons -->
	<script src="https://use.fontawesome.com/98be7b8a74.js"></script>
	<!-- Fonts by Google -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
</head>

<body id="page" class="index">


	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
	      </button>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	    <div class="row">
	      <div class="navbar-left">
	      	<a id="homelink" href="http://jacobpawlak.tech/index.php"><button type="button" class="btn btn-outline-danger" id="homebtn"><i class="fa fa-home fa-lg" aria-hidden="true"></i>  Home</button></a>
			<form id="searchbar" role="form" alt="Search form" label="search" action='search.php' method='post'>
				<input id="txtSearch" type="search" name="searchword" placeholder="Search..." alt="Search form" role="searchbox">
			</form>
	      </div>
	      <?php

	      //$_SESSION["username"] = 
	      
	      ?>

	      <div class="navbar-right" id="login">
				<form class="form-inline loginbox" method='post' action="login.php">
					<div class="form-group">
    					<label class="sr-only" for="user-email">Email address</label>
    					<input type="email" class="form-control" name="user-email" placeholder="Email">
  					</div>
  					<div class="form-group">
    					<label class="sr-only" for="user-pass">Password</label>
    					<input type="password" class="form-control" name="user-pass" placeholder="Password">
  					</div>
  					<button name='signin' type="submit" class="btn btn-default">Sign in</button>
  					<a href="registration.php"><button name='register' type="button" class="btn btn-default btn-outline-danger" id="registerbtn"> Register </button></a>
				</form>

			</div>
			<?php

				if ($_SESSION["isadmin"]) {
					echo "Hello, {$_SESSION['username']}";
					
				}
			?>

	      
	    </div>
	    </div>
	  </div>
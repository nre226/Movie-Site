
<?php

	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
	if (!$conn) {
		die("Didnt conek sonny");
	}
	$curr_db = mysql_select_db('405GMDB', $conn);

	$firstname = ($_POST["firstName"]);
	$middlename = ($_POST["middleName"]);
	$lastname = ($_POST["lastName"]);
	$email = ($_POST["email"]);
  	$password = ($_POST["password"]);
  	$birthdate = ($_POST["birthDate"]);
  	$gender = ($_POST["genderRadio"]);

	$select = mysql_query("SELECT email FROM user WHERE email = $email ");
	if(mysql_num_rows($select))
		exit("This email is already being used");
	$num_rows = mysql_num_rows(mysql_query("SELECT * FROM user"));
	$query = "INSERT INTO `user`(`user_id`, `email`, `gender`, `type`, `dob`, `pass`, `fname`, `mname`, `lname`) VALUES ($num_rows + 1, '$email' , '$gender', 'user','$birthdate', '$password', '$firstname', '$middlename', '$lastname')";
	if (mysql_query($query)) {
		echo "<script type='text/javascript'>alert('Thank you for registering $firstname!');</script>";
		echo "<script type='text/javascript'>
    		window.location = 'index.php';
		</script>";
	}
	else {
		echo "Error: " . $query . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);
?>

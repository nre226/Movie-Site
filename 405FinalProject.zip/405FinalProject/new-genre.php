<?php
	include "header.php";
?>

	<div class="container">
	    <form class="form-horizontal" role="form" method="post" action="addGenre.php">
	    <h2>Make a New Genre</h2>
	    <hr/>
	        <div class="form-group">
	            <label for="genre" class="col-sm-3 control-label">Movie Genre</label>
	            <div class="col-sm-9">
	                <input type="text" name="genre" placeholder="Genre" class="form-control" autofocus>
	            </div>
	        </div>

	        <?php
	        	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
				if (!$conn) {
					die("Didnt conek sonny");
				}
				$curr_db = mysql_select_db('405GMDB', $conn);

				$query = "SELECT title, movie_id FROM movies";

				$result = mysql_query($query);
				echo '<div class="form-group">';
				echo '<label for="movies" class="col-sm-3 control-label">Movie</label>';
				echo '<div class="col-sm-9">';
				echo "<select id='movies' name='movie-id' class='form-control'>";
				while ($row = mysql_fetch_assoc($result)) {
   					echo "<option value='{$row["movie_id"]}'>{$row["title"]}</option>";
				}
				echo "</select>";
				echo "</div>";
				echo "</div>";
	        ?>

	        
	        <div class="form-group">
	            <div class="col-sm-9 col-sm-offset-2" role="submitbutton">
	                <button type="submit" class="btn btn-primary btn-block">Add Genre</button>
	            </div>
	        </div>
	    </form> <!-- /form -->

	</div> <!-- ./container -->

<?php
	include "footer.php";
?>
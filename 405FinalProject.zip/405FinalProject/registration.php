<?php include "header.php"; ?>

	<div class="row">
	    <div class="col-md-12">
			<div class="splash">
				<img class="banner" src="Imgs/header.png">
			</div>
	    </div>
	</div>

	<div class="container">
	            <form class="form-horizontal" role="form" method="post" action="register.php">
	                <h2>Sign Up</h2>
	                <hr/>
	                <div class="form-group">
	                    <label for="firstName" class="col-sm-3 control-label">First Name</label>
	                    <div class="col-sm-9">
	                        <input type="text" name="firstName" placeholder="John" class="form-control" autofocus>
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label for="middleName" class="col-sm-3 control-label">Middle Name</label>
	                    <div class="col-sm-9">
	                        <input type="text" name="middleName" placeholder="Henry" class="form-control">
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label for="lastName" class="col-sm-3 control-label">Last Name</label>
	                    <div class="col-sm-9">
	                        <input type="text" name="lastName" placeholder="Doe" class="form-control">
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label for="email" class="col-sm-3 control-label">Email</label>
	                    <div class="col-sm-9">
	                        <input type="email" name="email" placeholder="Email" class="form-control">
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label for="password" class="col-sm-3 control-label">Password</label>
	                    <div class="col-sm-9">
	                        <input type="password" name="password" placeholder="Password" class="form-control">
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label for="birthDate" class="col-sm-3 control-label">Date of Birth</label>
	                    <div class="col-sm-9">
	                        <input type="date" name="birthDate" class="form-control">
	                    </div>
	                </div>
	                <div class="form-group">
	                    <label class="control-label col-sm-3">Gender</label>
	                    <div class="col-sm-6">
	                        <div class="row">
	                            <div class="col-sm-6">
	                                <label class="radio-inline">
	                                    <input type="radio" name="genderRadio" value="F">Female
	                                </label>
	                            </div>
	                            <div class="col-sm-6">
	                                <label class="radio-inline">
	                                    <input type="radio" name="genderRadio" value="M">Male
	                                </label>
	                            </div>
	                            <div class="col-sm-6">
	                                <label class="radio-inline">
	                                    <input type="radio" name="genderRadio" value="O">Other
	                                </label>
	                            </div>
	                        </div>
	                    </div>
	                </div> <!-- /.form-group -->
	                <div class="form-group">
	                    <div class="col-sm-9 col-sm-offset-2" role="submitbutton">
	                        <button type="submit" class="btn btn-primary btn-block">Register</button>
	                    </div>
	                </div>
	            </form> <!-- /form -->

	        </div> <!-- ./container -->
	        <br><br><br><br>
<?php include 'footer.php'; ?>
<?php

	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
	if (!$conn) {
		die("Didnt conek sonny");
	}
	$curr_db = mysql_select_db('405GMDB', $conn);

	$title = ($_POST["movie-title"]);
	$description = ($_POST["movie-description"]);
	$release = ($_POST["movie-release"]);
	$duration = ($_POST["movie-duration"]);
  	$language = ($_POST["movie-language"]);
  	
	//$select = mysql_query("SELECT email FROM user WHERE email = $email ");
	//if(mysql_num_rows($select))
	//	exit("This email is already being used");
	$num_rows = mysql_num_rows(mysql_query("SELECT * FROM movies"));
	$query = "INSERT INTO `movies`(`movie_id`, `movie_pic`, `title`, `description`, `release`, `duration`, `language`) VALUES (($num_rows + 1), 'Imgs/fifthelement.jpg', '$title', '$description', '$release', $duration, '$language')";
	if (mysql_query($query)) {
		echo "<script type='text/javascript'>alert('Thank you for adding $title!');</script>";
		echo "<script type='text/javascript'>
    		window.location = 'index.php';
		</script>";
	}
	else {
		echo "Error: " . $query . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);
?>

<?php include 'header.php';
	  include 'admintools.php'; ?>
		
	<div class="row">
	    <div class="col-md-12">
			<div class="splash">
				<img class="banner" src="Imgs/header.png">
			</div>
	    </div>
	</div>
	<br><br>
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<h1>Popular Movies</h1>
				<div class="row">
					<div class="slideshow">

						<?php
							$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
							if (!$conn) {
								die("Didnt connect son");
							}
							$curr_db = mysql_select_db('405GMDB', $conn);
							
							$num_movies = mysql_num_rows(mysql_query("SELECT * FROM movies"));
							$num_ratings = mysql_num_rows(mysql_query("SELECT * FROM rating"));
							
							$query = "SELECT * FROM movies WHERE duration > 0";
							$result = mysql_query($query);
						
							
							for ($i = 0; $i<10; $i++) {
								
								$imgurl = mysql_result($result, $i, 'movie_pic');
								$movietitle = mysql_result($result, $i, 'title');
								echo "<form method='post' action='single.php'>
  										<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  										<button type='submit' name='movie-name' value='$movietitle' class='link-button'>
    										<img data-lazy='$imgurl'>
  										</button>
								</form>";		
							}
							mysqli_close($conn);
						?>
					</div>
				</div>

			</div>
			<div class="col-md-1"></div>
			<div class="col-md-3">
				<h3>Your Watch List</h3>
				<table class="table">
				    <thead>
				      <tr>
				        <th>Title</th>
				        <th></th>
				      </tr>
				    </thead>
				    <tbody>
				      <tr>
				        <td><a href="#">The Hateful Eight</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">MoonRise Kingdom</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">2001: A Space Odyssey</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">The Big Lebowski</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">Flubber</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">Saving Private Ryan</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">A Scanner Darkly</a></td>
				        <td></td>
				      </tr>
				      <tr>
				        <td><a href="#">Waynes World</a></td>
				        <td></td>
				      </tr>
				    </tbody>
				</table>
			</div>
		</div>
 	</div>


    <!-- <script>require('initialize');</script> -->
    <div id="popup" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>You're pushing my buttons.</p>
        </div>
    </div>

    <script>
        var modal= document.getElementById('popup');
        var btn= document.getElementById('start');
        var span= document.getElementsByClassName('close')[0];

        btn.onclick= function() {
            modal.style.display = "block";
        }

        span.onclick= function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>


	<script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script type="text/javascript" src="slick/slick.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('.slideshow').slick({
				lazyLoad:'ondemand',
				infinite: true,
				speed: 300,
				slidesToShow: 4,
				slidesToScroll: 4,
				responsive: [
				{
				  breakpoint: 1024,
				  settings: {
				    slidesToShow: 3,
				    slidesToScroll: 3,
				  }
				},
				{
				  breakpoint: 600,
				  settings: {
				    slidesToShow: 2,
				    slidesToScroll: 2
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
				    slidesToShow: 1,
				    slidesToScroll: 1
				  }
				}
				// You can unslick at a given breakpoint now by adding:
				// settings: "unslick"
				// instead of a settings object
				]
			});
		});
	</script>
	
<?php include 'footer.php'; ?>

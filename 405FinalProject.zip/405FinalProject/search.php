<?php include "header.php"; ?>

<div class="row">
    <div class="col-md-12">
		<div class="splash">
			<img class="banner" src="Imgs/header.png">
		</div>
    </div>
</div>
<br><br>

<?php

	$conn = mysql_connect('localhost:3306', 'JacobPawlak', '0200JP0830');
	if (!$conn) {
		die("Didnt conek sonny");
	}
	$curr_db = mysql_select_db('405GMDB', $conn);

	$searchword = ($_POST["searchword"]);
	$useremail = ($_POST["user-email"]);
	$userpass = ($_POST["user-pass"]);
  	
	//$select = mysql_query("SELECT email FROM user WHERE email = $email ");
	//if(mysql_num_rows($select))
	//	exit("This email is already being used");
	$loginquery = "SELECT email, pass FROM user WHERE ((email = '$useremail') AND (pass = '$userpass'))";
	if (mysql_query($loginquery)) {
	    echo "<div class='navbar-right' id='login'>
	      	<p id='greeting'>Hello, $useremail</p>
	      </div>";
		//include "admintools.php";
		
	}
	else {
		echo "<p id='signinerror' >Sorry, that email or password does not seem to be in our records, please try again</p>";
	}
	
	$num_movies = mysql_num_rows(mysql_query("SELECT * FROM movies"));
	$num_tags = mysql_num_rows(mysql_query("SELECT * FROM tag"));
	$num_roles = mysql_num_rows(mysql_query("SELECT * FROM roles"));
	$num_ratings = mysql_num_rows(mysql_query("SELECT * FROM rating"));
	$num_crews = mysql_num_rows(mysql_query("SELECT * FROM crew"));
	$num_genres = mysql_num_rows(mysql_query("SELECT * FROM genre"));

	$result_movies = mysql_query("SELECT * FROM movies Where title LIKE '%$searchword%'");
	echo "<p class='searchtitle'>Movies with $searchword in them</p>";
	while ($row = mysql_fetch_assoc($result_movies)) {
		
		echo "<form method='post' action='single.php'>
  				<input type='hidden' name='extra_submit_param' value='extra_submit_value'>
  				<button type='submit' name='movie-name' value='{$row["title"]}' class='link-button'>
    				Title: {$row["title"]}
  				</button>
			</form>";
   		echo "<br>";
   		echo "<p class='movie-info'>Description: {$row["description"]}</p>";
   		echo "<br>";
   		echo "<p class='movie-info'>Release Date: {$row["release"]}</p>";
   		echo "<br>";
   		echo "<p class='movie-info'>Duration: {$row["duration"]} minutes</p>";
   		echo "<br>";
   		echo "<p class='movie-info'>Language: {$row["language"]}</p>";
   		echo "<br>";
	}
	include "admintools.php";
	mysqli_close($conn);
?>

<?php  include "footer.php"; ?>